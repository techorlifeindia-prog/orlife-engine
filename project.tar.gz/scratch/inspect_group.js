async function inspect() {
  const res = await fetch('http://localhost:8080/group/fetchAllGroups/device_1788680296230');
  const groups = await res.json();
  console.log(`Total groups: ${groups.length}`);
  if (groups.length > 0) {
    const sample = groups[0];
    console.log("Group Subject:", sample.subject);
    console.log("Sample Participants:", JSON.stringify(sample.participants.slice(0, 5), null, 2));
  }
}

inspect().catch(console.error);
